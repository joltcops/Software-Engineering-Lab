#include <bits/stdc++.h>
using namespace std;
//Class to implement the DataVector library
//Performs basic vector operations of vector addition, subtraction, dot and norm
//Also includes a function to find the distance between two vectors of same dimension
//For the given mnist dataset, the dimension of each DataVector is 784 (contains 784 pixels each)
class DataVector
{
    public:
    vector<double> v;//Main vector for storing the pixels as double values
    //Default constructor for initialising vector v with given or default dimension
    DataVector (int dimension=0);
    //Destructor for destroying the initialised DataVector
    ~DataVector();
    //Copy constructor
    DataVector (const DataVector& other);
    //Overloading the assignment operator for DataVectors
    DataVector & operator=(const DataVector &other);
    //Copy Assignment operator
    DataVector& operator=(const vector<double>& vec);
    //Function to set the dimension of a DataVector
    void setDimension(int dimension=0);
    //Overloading the addition operator to return the sum of 2 DataVectors of same dimension
    DataVector operator+(const DataVector& other);
    //Overloading the subtraction operator to return the difference between 2 DataVectors of same dimension
    DataVector operator-(const DataVector& other);
    //Overloading the * operator to find the dot product of 2 DataVectors of same dimension
    double operator*(const DataVector& other);
    //Finding the norm or modulus of 2 DataVectors as (*this)*(*this)
    double norm();
    //Finding the distance between 2 DataVectors using the norm function
    double dist(const DataVector& b);
    bool less(DataVector &other, DataVector &rule);
};