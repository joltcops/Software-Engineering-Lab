#include "TreeIndex.h"
VectorDataset *dataset = new VectorDataset;

DataVector Tree::KDNormal(int dim, int idx)
{
    DataVector rule(dim);
    for (int i=0; i<rule.v.size(); i++)
    rule.v[i]=0;
    rule.v[idx]=1;
    return rule;
}

DataVector Tree::RPNormal(int dim)
{
    DataVector rule(dim);
    srand(time(NULL));
    double sum=0.0;
    for (int i=0; i<rule.v.size(); i++)
    {
        rule.v[i]=rand()*10;
        sum+=rule.v[i]*rule.v[i];
    }
    for (int i=0; i<rule.v.size(); i++)
    rule.v[i]/=sum;
    return rule;
}


void Tree::MakeTree()
{
    int size = c->indices.size();
    c->delta.resize(c->indices.size(), 0);
    if(size<=BASE)
    {
        return;
    }
    c->rule = (type==0)?KDNormal(dataset->data[0].v.size(), c->index):RPNormal(dataset->data[0].v.size());
    sort(c->indices.begin(), c->indices.end(), [this](int i, int j){return dataset->data[i].less(dataset->data[j], c->rule);});
    c->median = dataset->data[(c->indices[size/2])]*c->rule;
    vector<int> v1;
    vector<int> v2;

    for(int i=0;i<size;++i)
    {
        srand(time(0));
        if(type==1) 
        c->delta[i]=(((double)rand()/RAND_MAX)*2-1)*6*dataset->maxDist(dataset->data[(c->indices[i])])/sqrt(dataset->data[0].v.size());
        if(dataset->data[(c->indices[i])]*c->rule<c->median+c->delta[i])
        v1.push_back(c->indices[i]);
        else
        v2.push_back(c->indices[i]);
    }
    //Printing number of DataVectors stored
    cout<<size<<endl;
    //Printing index of median computation and median value for splitting
    cout<<c->index<<" "<<c->median<<endl;
    //Printing size of left and right subtree
    cout<<v1.size()<<" "<<v2.size()<<endl;
    //Initialising left and right subtrees
    left = new Tree((c->index+1)%(dataset->data[0].v.size()), type, v1);
    right = new Tree((c->index+1)%(dataset->data[0].v.size()), type, v2);
    //Recursively calling left and right subtree
    left->MakeTree();
    right->MakeTree();
}

VectorDataset Tree::search(DataVector *d, int k)
{
    priority_queue<pair<double, int> > pq;
    Recurse(d, k, pq);
    VectorDataset closest;
    while(!pq.empty())
    {
        closest.data.push_back(dataset->data[pq.top().second]);
        pq.pop();
    }
    return closest;
}                               

void Tree::Recurse(DataVector *d, int k, priority_queue<pair<double, int> > &maxheap)
{
    if(left == NULL && right == NULL)
    {
        knearest(*d, k, maxheap);
        return;
    }
    double dis = (*d)*(c->rule);
    double deltval = (type==1)?(((float)rand()/RAND_MAX)*2-1)*6*dataset->maxDist(*d)/sqrt(d->v.size()):0;
    if((*d)*(c->rule)<(c->median)+deltval)
    {
        left->Recurse(d, k, maxheap);
        if(maxheap.size()<k || dis<maxheap.top().first)
        {
            right->Recurse(d, k, maxheap);
        }
    }
    else
    {
        right->Recurse(d, k, maxheap);
        if(maxheap.size()<k || dis<=maxheap.top().first)
        {
            left->Recurse(d, k, maxheap);
        }
    }
}

void Tree::knearest(DataVector &query, int k, priority_queue<pair<double, int> > &pqueue)
{            
    for(int i=0;i<c->indices.size();i++)
    {
        if(pqueue.size()<k)
        pqueue.push(make_pair(dataset->data[c->indices[i]].dist(query), c->indices[i]));
        else
        {
            if(pqueue.top().first>dataset->data[c->indices[i]].dist(query))
            {
                pqueue.pop();
                pqueue.push(make_pair(dataset->data[c->indices[i]].dist(query), c->indices[i]));
            }
        }
    }
}
class TreeIndex 
{
    Tree *root;
    protected:
        //Constructor
        TreeIndex(int i, int t): root(new Tree(i, t, vector<int>(dataset->data.size(), 0)))
        {
            for(int i=0;i<dataset->data.size();i++) 
            root->c->indices[i] = i;
            root->MakeTree();
        };
    public:
        static int type;
        //Returns a tree instance
        static TreeIndex& GetInstance(int i, int t)
        {
            static TreeIndex instance(i, t);
            return instance;
        }
        //Destructor
        ~TreeIndex() 
        {
            delete root;
        }
        //Adds a new DataVector and computes a new tree corresponding to it
        void AddData(DataVector* query)
        {
            dataset->data.push_back(*query);
            root->MakeTree();
        }
        //Removes a DataVector and computes a new tree
        void RemoveData(DataVector* query)
        {
            vector<DataVector>::iterator it;
            it=dataset->data.begin();
            if(it!=dataset->data.end())
            dataset->data.erase(it);
            root->MakeTree();
        }
        //Returns the VectorDataset corresponding to the k nearest neighbours
        VectorDataset knn(DataVector *v, int k)
        {
            return root->search(v, k);
        }
};
class KDTreeIndex : public TreeIndex 
{
    private:
        KDTreeIndex(): TreeIndex(dataset->data[0].v.size()/2, 0){}
        ~KDTreeIndex() {}
    public:
        //Ensures that the class KDTreeIndex is singleton
        static KDTreeIndex& GetInstance()
        {
            if(type == 1)
            {
                cout<<"ERROR"<<endl;
                exit(1);
            }
            static KDTreeIndex instance;
            type = 0;
            return instance;
        }
        
};
class RPTreeIndex : public TreeIndex 
{
    private:
        RPTreeIndex(): TreeIndex(-1, 1){}
        ~RPTreeIndex() {}
    public:
        //Ensures that the class RPTreeIndex is singleton
        static RPTreeIndex& GetInstance()
        {
            if(type == 0)
            {
                cout<<"ERROR"<<endl;
                exit(1);
            }
            static RPTreeIndex instance;
            type = 1;
            return instance;
        }
};
int TreeIndex::type = -1;
int main()
{
    //Read the DataVector
    *dataset=dataset->ReadDataset("small.csv");
    cout<<"Enter index of the DataVector: ";
    int idx;
    cin>>idx;
    DataVector query=dataset->data[idx];
    int k, ch;
    cout<<"Enter 0 for KD Tree and 1 for RP Tree: ";
    cin>>ch;
    cout<<"Enter k: ";
    cin>>k;
    if(ch==0)
    {
        KDTreeIndex::GetInstance().knn(&query, k).PrintVec();
        cout<<endl;
        cout<<"Adding Data"<<endl;
        KDTreeIndex::GetInstance().AddData(&query);
        cout<<endl;
        cout<<"Removing Data"<<endl;
        KDTreeIndex::GetInstance().RemoveData(&query);
        cout<<endl;
    }
    else if(ch==1)
    {
        RPTreeIndex::GetInstance().knn(&query, k).PrintVec();
        cout<<endl;
        cout<<"Adding Data"<<endl;
        RPTreeIndex::GetInstance().AddData(&query);
        cout<<endl;
        cout<<"Removing Data"<<endl;
        RPTreeIndex::GetInstance().RemoveData(&query);
        cout<<endl;
    }
    else
    cout<<"Wrong choice"<<endl;
    return 0;
}