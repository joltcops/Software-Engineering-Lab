#include "VectorDataset.h"
#define BASE 5
//Defines a wrapper structure containing all fields for a node
//Contains an array of indices corresponding to the DataVectors
//Contains the median value and the index for which median is computed
//Contains the DataVector Rule, which is a normal to the plane of the vector
//For a KD tree, it contains a 1 only for the median index, and 0 elsewhere
//For RP Tree, the plane is a random unit vector
//Delta is for the random RP Tree
typedef struct cont
{
    vector<int> indices;
    int index;
    DataVector rule;
    vector<double> delta;
    double median;
} wrapper;
//Defines the functions which are common for constructing both the KD as well as RP Tree
class Tree
{
    Tree* left;//Left node pointer
    Tree* right;//Right node pointer
    int type;//Type 0 for KD Tree and 1 for RP Tree
    friend class TreeIndex;
    public:
    wrapper* c;
    //Constructor
    Tree(int idx, int t, vector<int>ex):left(NULL), right(NULL), type(t)
    {
        c = new wrapper;
        c->indices = ex;
        c->delta.resize(c->indices.size(), 0);
        c->median = -1;
        c->index = idx;
    }
    //Destructor
    ~Tree()
    {
        delete left;
        delete right;
        delete c;
    }
    public:
    //Initialises the rule DataVector for the KD Tree
    DataVector KDNormal(int dim, int idx);
    //Initialises the random unit DataVector for the RP Tree
    DataVector RPNormal(int dim);
    //Function to build the tree
    void MakeTree();
    //Returns the k nearest neighbours in form of a VectorDataset
    VectorDataset search(DataVector* d, int k);
    //Helper function which recursively calls either the left or the right tree node to give the nearest neighbours
    void Recurse(DataVector* d, int k, priority_queue<pair<double, int>>& maxheap);
    //Push the k nearest neighbours into a heap using the following algorithm
    //If the size of the queue is less than k or the current distance is less than that at the queue top, we push
    //If the queue size exceeeds k at any point, we pop the least nearest neighbour
    void knearest(DataVector &query, int k, priority_queue<pair<double, int> > &maxheap);
    //Prints the indices of the DataVectors in each node
    void printTree();
};