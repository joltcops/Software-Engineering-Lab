#include "DataVector.h"
DataVector::DataVector(int dimension)
{
    v.resize(dimension);
}
DataVector::DataVector (const DataVector& other)
{
    v=other.v;
}
DataVector::~DataVector()
{
    v.clear();
}
void DataVector::setDimension(int dimension)
{
    v.clear();
    v.resize(dimension);
}
DataVector& DataVector:: operator=(const DataVector& other)
{
    if(this!=&other)
    v=other.v;
    return *this;
}
DataVector& DataVector:: operator=(const vector<double>& vec)
{
    v=vec;
    return *this;
}
DataVector DataVector:: operator+(const DataVector& other)
{
    DataVector x(v.size());
    for (int i=0; i<v.size(); i++)
    x.v[i]=v[i]+other.v[i];
    return x;
}
DataVector DataVector:: operator-(const DataVector& other)
{
    DataVector x(v.size());
    for (int i=0; i<v.size(); i++)
    x.v[i]=v[i]-other.v[i];
    return x;
}
double DataVector::operator*(const DataVector& other)
{
    double res=0.0;
    for (int i=0; i<v.size(); i++)
    res+=(double)v[i]*other.v[i];
    return (double)res;
}
double DataVector::norm()
{
    double res;
    res=(*this)*(*this);
    res=(double)sqrt(res);
    return (double)res;
}
double DataVector::dist(const DataVector& b)
{
    double res;
    DataVector diff=*this-b;
    res=diff.norm();
    return (double)res;
}
bool DataVector::less(DataVector &other, DataVector &rule)
{
    return (*this)*rule<other*rule;
}