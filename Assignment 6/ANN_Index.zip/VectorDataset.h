#include <bits/stdc++.h>
#include "DataVector.h"
//Class to implement the VectorDataset library
//Contains functionality to convert the .csv file data input of train and test vectors into VectorDataset
//Implements a vector of DataVectors, which in turn translates to a vector of double vectors
//The VectorDataset of the training set contains 60000 DataVectors each of 784 pixels
//The test VectorDataset contains 10000 such DataVectors. It is for the test dataset that we note the testing time after training
class VectorDataset
{
    public:
    vector<DataVector> data;//Main vector which is a vector of DataVectors
    //Default constructor to initialise the VectorDataset
    VectorDataset();
    //Destructor for a VectorDataset
    ~VectorDataset();
    //Function to convert the .csv train and test input to a vector, which can be manipulated easily to implement the algorithm
    static VectorDataset ReadDataset(const std::string& filename);
    void PrintVec();
    double maxDist(const DataVector& query);
};