#include "VectorDataset.h"
VectorDataset::VectorDataset()
{}
VectorDataset::~VectorDataset()
{
    data.clear();
}
VectorDataset VectorDataset::ReadDataset(const std::string& filename)
{
    VectorDataset f;
    std::ifstream file(filename);
    if (!file.is_open())
    {
            std::cerr << "Error opening the file!" << std::endl;
            return f;
    }
    std::string line;
    int i=0;
    std::getline(file, line);
    while (std::getline(file, line))
    {
        vector<double>values;
        std::istringstream iss(line);
        char comma;
        double val;
        while (iss>>val)
        {
            values.push_back(val);
            if (iss>>comma && comma!=',')
            {
                std::cerr<<"Error"<<endl;
                return f;
            }
        }
        DataVector temp;
        temp.v=values;
        DataVector datavector(temp);
        f.data.push_back(datavector);
        i++;
    }
    file.close();
    return f;
}