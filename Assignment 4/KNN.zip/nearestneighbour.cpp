#include "VectorDataset.h"
/*Implementation
* The basic unit of input data, a DataVector is implemented as a library in header DataVector.h
* Class DataVector acts as a user defined datatype storing data as a vector of double values
* It also contains functions to perform essential vector operations for manipulations
* A collection of DataVectors taken together is defined in VectorDataset class as a user defined datatype
* It also contains a function to read the dataset and convert it into a computable VectorDataset
* The K Nearest Neighbour algorithm is run on a DataVector to find its closest neighbours corresponding to a given VectorDataset
* The algorithm starts off with storing the distances between the given DataVector and each of the DataVectors in VectorDataset
* It makes a pair of double and int values to store the corresponding index as well
* Then the pair is sorted in ascending order and the first k DataVectors are stored
* The new VectorDataset of dimension k is returned
* The average time taken per test vector is noted by computing the total time for first 100 test vectors and dividing by 100
*/
//Implements the K Nearest Neighbour algorithm
VectorDataset knearestneighbour(const VectorDataset& vdata, DataVector dvec, int k)
{
    VectorDataset f;
    vector <pair<double, int>> d;
    d.resize(vdata.data.size());
    //cout<<vdata.data.size()<<endl;
    int p=0;
    //for (int i=0; i<dvec.v.size(); i++)
    //cout<<dvec.v[i]<<" ";
    //cout<<endl;
    for (int i=0; i<vdata.data.size(); i++)
    {
        d[i]=make_pair((double)dvec.dist(vdata.data[i]), i);
        //cout<<vdata.data[i].v.size()<<endl;
    }
    std::sort(d.begin(), d.end());
    f.data.resize(k);
    for (int i=0; i<k; i++)
    {
        cout<<"Index "<<d[i].second<<endl;
        for (int j=0; j<784; j++)
        cout<<vdata.data[d[i].second].v[j]<<" ";
        cout<<endl;
        f.data[i]=d[i].second;
    }
    return f;
}
int main()
{
    int k;
    cout<<"Enter k: ";
    cin>>k;
    VectorDataset train;
    train=VectorDataset::ReadDataset("fmnist-train.csv");
    VectorDataset test;
    test=VectorDataset::ReadDataset("fmnist-test.csv");
    auto start = std::chrono::high_resolution_clock::now();
    for(int i=0; i<100; i++)
    {
        DataVector numbers(784);
        numbers=test.data[i];
        VectorDataset res=knearestneighbour(train, numbers, k);
    }
    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    // Display the execution time
    std::cout << "Average Time taken: " << ((double)duration.count()/100.0)/1000000.0 << " seconds"<<endl;
}