#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct cord
{
    float x, y;
} coord;
struct indiv
{
    int uid;
    char* name;
    char* date;
    char* birth;
    int nc;
    char** content;
};
struct business
{
    int uid;
    char** content;
    coord loc;
    int on, cn;
    int nc;
    struct indiv* owner;
    struct indiv* cust;
};
struct organise
{
    coord loc;
    int m;
    struct indiv* member;
};
struct group
{
    int memb, busi;
    struct indiv* member;
    struct business* bus;
};
struct node
{
    int uid;
    char* name, *date;
    int nc;
    char** content;
    int type;
    struct indiv i;
    struct business b;
    struct organise o;
    struct group g;
    struct node* next;
};