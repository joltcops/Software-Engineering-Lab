#include "social.h"
/*
Implementation:
* The main() function is the master text interface. It first initialises the global post array as well as the global linked list of nodes
* Four different structures corresponding to each of the four types of nodes have been defined in "social.h"
* These 4 types have been integrated into a single struct node, which has a parameter int type specifying the type of the node
* We fill the details into struct node depending on which kind of node it should represent
* Since all nodes have fields uid, name, date and content common, these have been implemented directly in struct node
instead of repeating in each and every field
* In order to save memeory, we make sure that when content is reposted, it is not duplicated.
* For this, we maintain a global array of posts (string objects), and we enter posts only if it is not present already
* The global linked list s maintains a set of all nodes with their relevant links
* No individual is directly linked to another, but they are members of groups, business or organisations
* This has been implemented by creating an array of members or customers and owners within the individual node for business or group
* When an individual or business is being linked, we also check whether the uid being enter matches the type of node, else an appropriate message is displayed
* In the main function, the user is displayed a list of options to perform an action in each iteration, each entry is processed accordingly
* Note that 'Y' and 'N' is NOT case sensitive here
* Note that if a node does not have any content of its own, then nothing is printed as content
* The user enters the set of nodes it wants to be created.
* The user should always enter a unique value of uid, else create() will display an error message
* For entering nodes into a business, the create() function checks whether the individual already exists, if not, it displays a message
* Similarly, for functions like delete(), we first check the existence of the node and then proceed on to deletion
* The search function provides functionality for searching in 3 ways: either by name or by type or by date of birth
* For search by name, substring based search has been implemented
* As soon as we find nodes with name having the entered string as its substring, those nodes are displayed
* Similar algorithm has been implemented for search by type too
* However substring search has not been implemented for search by birth, as the date of birth is unique
* print_one_hop() function prints only the unique ids of one hop or directly connected nodes
* Here one hop nodes for an individual refers to all the groups or organisations or business it is a part of
* Whereas for a group or organisation or business, it refers to all the individuals contained in it
*/
int pi=0;//Global variable to keep track of number of unique posts (string objects) created so far
struct node* s;//Global linked list of nodes
char** post;//Global linked list of posts (string objects)
//Function to search for a node based on name or type or birthday
//Type 1 searches based on name
//Type 2 searches based on birthday
//Type 3 searches by type
//Type 4 is a utility to help search by uid
struct node* search(int type, char* x, int t)
{
    if (type==1)//Search by name x
    {
        struct node* cpy=s;//Temporary copy of current node
        struct node* ret=NULL;
        int count=0;
        while(cpy)
        {
            if (strstr(cpy->name,x) && cpy)
            {
                count++;
                printf ("Node found: Unique ID: %d\nName: %s\n", cpy->uid, cpy->name);
                ret=cpy;
            }
            cpy=cpy->next;
        }
        return ret;
    }
    if (type==2)//Search by birth
    {
        struct node* cpy=s;
        while(cpy)
        {
            if(cpy->i.birth==NULL)
            {
                cpy=cpy->next;
                continue;
            }
            if (!strcmp(cpy->i.birth,x) && cpy)
            return cpy;
            cpy=cpy->next;
        }
    }
    if (type==3)//Search by type
    {
        struct node* cpy=s;
        struct node* ret=NULL;
        int count=0;
        while(cpy)
        {
            if (cpy->type==t)
            {
                count++;
                printf ("Node found: Unique ID: %d\nName: %s\n", cpy->uid, cpy->name);
                ret=cpy;
            }
            cpy=cpy->next;
        }
        return ret;
    }
    if (type==4)//Search by uid
    {
        struct node* cpy=s;
        while (cpy)
        {
            if (cpy->uid==t)
            return cpy;
            cpy=cpy->next;
        }
    }
    return NULL;
}
//Search within the global post array whether a content(string object) already exists. If yes, then it is not duplicated
//Else it is entered into the global array
int search_post_global(char* cont)
{
    for (int i=0; i<=pi; i++)
    {
        if(strcmp(post[i],cont))
        return 1;
    }
    return 0;
}
//Utility function to print the details of an individual
void print1(struct indiv i)
{
    if ((i.uid)!=-1)
    printf ("********************************************************\n");
    printf ("Unique ID: %d\nName: %s\nDate: %s\n", i.uid, i.name, i.date);
    if(i.birth)
    printf ("Date of Birth: %s\n", i.birth);
    printf ("********************************************************\n");
}
//Utility function to print the details of a business
void print2(struct business b)
{
    if((b.uid)!=-1)
    printf ("********************************************************\n");
    printf ("Unique ID: %d\n", b.uid);
    printf ("Location: %f %f\n", b.loc.x, b.loc.y);
    if (b.on>0)
    {
        printf ("Owners:\n");
        for (int i=0; i<b.on; i++)
        {
            if(b.owner[i].uid!=-1)
            print1(b.owner[i]);
        }
    }
    if(b.cn>0)
    {
        printf ("Customers:\n");
        for (int i=0; i<b.cn; i++)
        {
            if((b.cust[i].uid)!=-1)
            print1(b.cust[i]);
        }
    }
    printf ("********************************************************\n");
}
//Utility function to print all the existing content in an individual's node
void printc(struct indiv n)
{
    for(int i=0; i<n.nc; i++)
    printf ("%s\n", n.content[i]);
}
//Utility function to print all the existing content in a business node
void print2c(struct business b)
{
    for(int i=0; i<b.nc; i++)
    printf (" %s\n", b.content[i]);
}
//Function to display Unique ID, Name, Date and existing content of all nodes in the global linked list
void display()
{
    struct node* cpy=s;
    printf ("********************************************************\n");
    while(cpy)
    {
        printf ("Unique ID: %d\nName: %s\nDate of creation: %s\n", cpy->uid, cpy->name, cpy->date);
        printf ("Type: ");
        if(cpy->type==1)
        printf ("Individual\n");
        else if(cpy->type==2)
        printf ("Business\n");
        else if(cpy->type==3)
        printf ("Organisation\n");
        else if(cpy->type==4)
        printf ("Group\n");
        if (cpy->type==1)
        {
            if(cpy->i.birth)
            printf ("Date of birth: %s\n", cpy->i.birth);
        }
        if(cpy->type==2)
        {
            printf ("Location: %f %f\n", cpy->b.loc.x, cpy->b.loc.y);
            if (cpy->b.on>0)
            {
                printf ("Owners:\n");
                for (int i=0; i<cpy->b.on; i++)
                {
                    if (cpy->b.owner[i].uid!=-1)
                    print1(cpy->b.owner[i]);
                }
            }
            if (cpy->b.cn>0)
            {
                printf ("Customers:\n");
                for(int i=0; i<cpy->b.cn; i++)
                {
                    if(cpy->b.cust[i].uid!=-1)
                    print1(cpy->b.cust[i]);
                }
            }
        }
        if(cpy->type==3)
        {
            printf ("Location: %f %f\n", cpy->o.loc.x, cpy->o.loc.y);
            if (cpy->o.m>0)
            {
                printf ("Members:\n");
                for (int i=0; i<cpy->o.m; i++)
                {
                    if(cpy->o.member[i].uid!=-1)
                    print1(cpy->o.member[i]);
                }
            }
        }
        if(cpy->type==4)
        {
            if (cpy->g.memb>0)
            {
                printf ("Members:\n");
                for (int i=0; i<cpy->g.memb; i++)
                {
                    if(cpy->g.member[i].uid!=-1)
                    print1(cpy->g.member[i]);
                }
            } 
            if(cpy->g.busi>0) 
            {
                printf ("Business included:\n");
                for(int i=0; i<cpy->g.busi; i++)
                {
                    print2(cpy->g.bus[i]);
                }
            }
        }
        if(cpy->nc>0)
        printf ("Content:\n");
        for (int i=0; i<cpy->nc; i++)
        printf ("%s\n", cpy->content[i]);
        cpy=cpy->next;
        printf ("********************************************************\n");
    }
    printf ("********************************************************\n");
}
//Function to create a node
//Type 1 refers to an individual node
//Type 2 refers to a business node
//Type 3 refers to an organisation node
//Type 4 refers to a group node
struct node* create()
{
    struct node* newnode=(struct node*)malloc(sizeof(struct node));
    newnode->i.birth=NULL;
    int type;
    //Taking input for the type of node as described below
    printf ("Enter type:\nType 1 for individual, Type 2 for business, Type 3 for organisation, Type 4 for group\n");
    scanf ("%d", &type);
    if (type==1)//Creates a node for an individual
    {
        struct indiv in;
        printf ("Enter unique ID: ");
        int temp;
        scanf ("%d", &temp);
        if (search(4, NULL, temp))
        {
            printf ("Unique ID already exists!\n");
            return s;
        }
        newnode->uid=temp;
        in.uid=newnode->uid;
        newnode->name=(char*)malloc(100*sizeof(char));
        in.name=(char*)malloc(100*sizeof(char));
        newnode->date=(char*)malloc(100*sizeof(char));
        in.date=(char*)malloc(100*sizeof(char));
        printf ("Enter name: ");
        scanf (" %[^\n]%*c", newnode->name);
        strcpy(in.name, newnode->name);
        printf ("Enter date: ");
        scanf (" %[^\n]%*c", newnode->date);
        strcpy(in.date,newnode->date);
        newnode->content=(char**)malloc(100*sizeof(char*));
        in.content=(char**)malloc(100*sizeof(char*));
        for (int i=0; i<100; i++)
        {
            newnode->content[i]=(char*)malloc(1000*sizeof(char));
            in.content[i]=(char*)malloc(1000*sizeof(char));
        }
        char c;
        printf ("Do you want to enter date of birth?(Y/N): ");
        scanf (" %c", &c);
        if (c=='Y'||c=='y')
        {
            in.birth=(char*)malloc(100*sizeof(char));
            newnode->i.birth=(char*)malloc(100*sizeof(char));
            printf ("Enter date of birth: ");
            scanf (" %[^\n]%*c", in.birth);
            strcpy(newnode->i.birth, in.birth);
        }
        in.nc=0;
        newnode->nc=0;
        newnode->i=in;
        newnode->type=1;
        newnode->next=NULL;
    }
    else if (type==2)//Creates a node for a business
    {
        struct business in;
        printf ("Enter unique ID: ");
        int temp;
        scanf ("%d", &temp);
        if (search(4, NULL, temp))
        {
            printf ("Unique ID already exists!\n");
            return s;
        }
        newnode->uid=temp;
        in.uid=newnode->uid;
        newnode->name=(char*)malloc(100*sizeof(char));
        newnode->date=(char*)malloc(100*sizeof(char));
        printf ("Enter name: ");
        scanf (" %[^\n]%*c", newnode->name);
        printf ("Enter date: ");
        scanf (" %[^\n]%*c", newnode->date);
        newnode->content=(char**)malloc(100*sizeof(char*));
        in.content=(char**)malloc(100*sizeof(char*));
        for (int i=0; i<100; i++)
        {
            newnode->content[i]=(char*)malloc(1000*sizeof(char));
            in.content[i]=(char*)malloc(1000*sizeof(char));
        }
        in.content=newnode->content;
        printf ("Enter location as x and y coordinates: ");
        scanf ("%f", &newnode->b.loc.x);
        scanf("%f", &newnode->b.loc.y);
        printf ("Enter number of owners and customers: ");
        scanf ("%d%d", &newnode->b.on, &newnode->b.cn);
        in.loc.x=newnode->b.loc.x;
        in.loc.y=newnode->b.loc.y;
        in.on=newnode->b.on;
        in.cn=newnode->b.cn;
        in.owner=(struct indiv*)malloc(100*sizeof(struct indiv));//Array of business owners
        in.cust=(struct indiv*)malloc(100*sizeof(struct indiv));//Array of business customers
        printf ("Enter owners\n");
        int c=0;
        for (int i=0; i<in.on; i++)
        {
            printf ("Enter the uid of the owner: ");
            //Adding owners into the owner array
            int id;
            scanf ("%d", &id);
            if (search(4, NULL, id) && search(4, NULL, id)->type==1)//Searching whether the individual exists
            {
                in.owner[c++]=search(4, NULL, id)->i;
                printf ("Successfully added!\n");
            }
            else
            {
                printf ("The individual does not exist!\n");
                in.on--;
            }
        }
        printf ("Enter customer details\n");
        c=0;
        for (int i=0; i<in.cn; i++)
        {
            printf ("Enter the uid of the customer: ");
            //Adding customers into the customer array
            int id;
            scanf ("%d", &id);
            if (search(4, NULL, id) && search(4, NULL, id)->type==1)//Searching for existence of the individual
            {
                in.cust[c++]=search(4, NULL, id)->i;
                printf ("Successfully added!\n");
            }
            else
            {
                printf ("The individual does not exist!\n");
                in.cn--;
            }
        }
        in.nc=0;
        newnode->nc=0;
        newnode->b=in;
        newnode->type=2;
        newnode->next=NULL;
    }
    else if (type==3)//Creates a node for an organisation
    {
        struct organise in;
        newnode->name=(char*)malloc(100*sizeof(char));
        newnode->date=(char*)malloc(100*sizeof(char));
        printf ("Enter unique ID: ");
        int temp;
        scanf ("%d", &temp);
        if (search(4, NULL, temp))
        {
            printf ("Unique ID already exists!\n");
            return s;
        }
        newnode->uid=temp;
        printf ("Enter name: ");
        scanf (" %[^\n]%*c", newnode->name);
        printf ("Enter date: ");
        scanf (" %[^\n]%*c", newnode->date);
        newnode->content=(char**)malloc(100*sizeof(char*));
        for (int i=0; i<100; i++)
        {
            newnode->content[i]=(char*)malloc(1000*sizeof(char));
        }
        printf ("Enter location as x and y coordinates: ");
        scanf ("%f%f", &in.loc.x, &in.loc.y);
        printf ("Enter number of members: ");
        scanf ("%d", &in.m);
        in.member=(struct indiv*)malloc(100*sizeof(struct indiv));
        printf ("Enter members\n");
        int c=0;
        for (int i=0; i<in.m; i++)
        {
            printf ("Enter the uid of the member: ");
            int id;
            scanf ("%d", &id);
            if (search(4, NULL, id) && search(4, NULL, id)->type==1)
            {
                in.member[c++]=search(4, NULL, id)->i;
                printf ("Successfully added!\n");
            }
            else
            {
                printf ("The individual does not exist!\n");
                in.m--;
            }
        }
        newnode->nc=0;
        newnode->o=in;
        newnode->type=3;
        newnode->next=NULL;
    }
    else if (type==4)
    {
        struct group in;
        printf ("Enter unique ID: ");
        int temp;
        scanf ("%d", &temp);
        if (search(4, NULL, temp))
        {
            printf ("Unique ID already exists!\n");
            return s;
        }
        newnode->uid=temp;
        newnode->name=(char*)malloc(100*sizeof(char));
        newnode->date=(char*)malloc(100*sizeof(char));
        printf ("Enter name: ");
        scanf (" %[^\n]%*c", newnode->name);
        printf ("Enter date: ");
        scanf (" %[^\n]%*c", newnode->date);
        newnode->content=(char**)malloc(100*sizeof(char*));
        for (int i=0; i<100; i++)
        {
            newnode->content[i]=(char*)malloc(1000*sizeof(char));
        }
        printf ("Enter number of members and businesses: ");
        scanf ("%d", &in.memb);
        scanf ("%d", &in.busi);
        in.member=(struct indiv*)malloc(100*sizeof(struct indiv));
        in.bus=(struct business*)malloc(100*sizeof(struct business));
        printf ("Enter members\n");
        int c=0;
        for (int i=0; i<in.memb; i++)
        {
            printf ("Enter the uid of the member: ");
            int id;
            scanf ("%d", &id);
            if (search(4, NULL, id) && search(4, NULL, id)->type==1)
            {
                in.member[c++]=search(4, NULL, id)->i;
                printf ("Successfully added!\n");
            }
            else
            {
                printf ("The individual does not exist!\n");
                in.memb--;
            }
        }
        printf ("Enter business details\n");
        c=0;
        for (int i=0; i<in.busi; i++)
        {
            printf ("Enter the uid of the business: ");
            int id;
            scanf ("%d", &id);
            if (search(4, NULL, id) && search(4, NULL, id)->type==2)
            {
                in.bus[c++]=search(4, NULL, id)->b;
                printf ("Successfully added!\n");
            }
            else
            {
                printf ("The business does not exist!\n");
                in.busi--;
            }
        }
        newnode->nc=0;
        newnode->g=in;
        newnode->type=4;
        newnode->next=NULL;
    }
    if(!s)
    {
        s=newnode;
    }
    else
    {
        struct node* l=s;
        while(l->next)
        l=l->next;
        l->next=newnode;
    }
    return s;
}
//Utility function to delete an individual node from the global linked list of nodes
struct node* deleten(struct node* del)
{
    struct node* c, *temp;
    c=s;
    if (del->uid==s->uid)//If the node happens to be in the beginning of the linked list
    {
        s=s->next;
        free(c);
        return s;
    }
    temp=s;
    s=s->next;
    while(s && del->uid!=s->uid)//If the node occurs in the middle or at the end
    {
        temp=s;
        s=s->next;
    }
    temp->next=s->next;
    free(s);
    return c;
}
//Deletes a nodes based on the type, calls deleten(struct node*) to delete a node
//Algorithm: If a node is a group or organisation, it cannot be nested within any other node, so we simply search and delete it
//If a node is an individual or a business, we have to traverse the entire linked list
//If it is found to be a part of any business or group or organisation, we remove its occurences from all of those nodes too
struct node* delete(int id)
{
    struct node* c=s;
    while(c)
    {
        if(c->uid==id)
        {
            s=deleten(c);//Search and delete
        }
        else if(c->type==2)//Check whether the node being searched for is nested within any other node, here a business
        {
            for (int i=0; i<c->b.on; i++)
            {
                if(c->b.owner[i].uid==id)
                c->b.owner[i]=(struct indiv){-1, NULL, NULL, NULL, -1, NULL};//Removing data if found within any other node
            }
            for (int i=0; i<c->b.cn; i++)
            {
                if(c->b.cust[i].uid==id)
                c->b.cust[i]=(struct indiv){-1, NULL, NULL, NULL, -1, NULL};
            }
        }
        else if(c->type==3)//Check whether the node being searched for is nested within any other node, here an organisation
        {
            for (int i=0; i<c->o.m; i++)
            {
                if(c->o.member[i].uid==id)
                c->o.member[i]=(struct indiv){-1, NULL, NULL, NULL, -1, NULL};
            }
        }
        else if(c->type==4)//Check whether the node being searched for is nested within any other node, here a group
        {
            for (int i=0; i<c->g.memb; i++)
            {
                if(c->g.member[i].uid==id)
                c->g.member[i]=(struct indiv){-1, NULL, NULL, NULL, -1, NULL};
            }
            for (int i=0; i<c->g.busi; i++)
            {
                if(c->g.bus[i].uid==id)
                c->g.bus[i]=(struct business){-1, NULL, (coord){0.0, 0.0}, -1, -1, -1, NULL, NULL};
            }
        }
        c=c->next;
    }
    return s;
}
//Function to post and display all existing content of a node
//If new content is being entered, we search to check whether it already exists
//If the new content being entered already exists, we do not duplicate it
struct node* cont_post()
{
    int id;
    printf ("Enter the uid of the node: ");
    scanf ("%d", &id);
    struct node* target=s;
    while(target)
    {
        if(target->uid==id)
        break;
        target=target->next;
    }
    if (!target)
    printf ("The node does not exist!\n");
    else
    {
        char* new_cont;
        char c;
        printf ("Do you want to upload new content?(Y/N): ");
        scanf (" %c", &c);
        if (c=='Y'||c=='y')
        {
            new_cont=(char*)malloc(100*sizeof(char));
            printf ("Enter new content: ");
            scanf (" %[^\n]%*c", new_cont);
            int flag=0;
            for (int i=0; i<target->nc; i++)
            {
                if(!strcmp(target->content[i],new_cont))
                flag=1;
            }
            if(!flag)
            {
                strcpy(target->content[target->nc++], new_cont);
                if (target->type==1)
                {
                    strcpy(target->i.content[target->i.nc], new_cont);
                    target->i.nc++;
                    struct node* copy=s;
                    while(copy)
                    {
                        if (copy->type==2)
                        {
                            for (int i=0; i<copy->b.on; i++)
                            {
                                if(copy->b.owner[i].uid==target->uid)
                                {
                                    strcpy(copy->b.owner[i].content[copy->b.owner[i].nc++], new_cont);
                                }
                            }
                            for (int i=0; i<copy->b.cn; i++)
                            {
                                if(copy->b.cust[i].uid==target->uid)
                                {
                                    strcpy(copy->b.cust[i].content[copy->b.cust[i].nc++], new_cont);
                                }
                            }
                        }
                        if (copy->type==3)
                        {
                            for (int i=0; i<copy->o.m; i++)
                            {
                                if(copy->o.member[i].uid==target->uid)
                                {
                                    strcpy(copy->o.member[i].content[copy->o.member[i].nc++], new_cont);
                                }
                            }
                        }
                        if (copy->type==4)
                        {
                            for (int i=0; i<copy->g.memb; i++)
                            {
                                if(copy->g.member[i].uid==target->uid)
                                {
                                    strcpy(copy->g.member[i].content[copy->g.member[i].nc++], new_cont);
                                }
                            }
                        }
                        copy=copy->next;
                    }
                }
                if(target->type==2)
                {
                    strcpy(target->b.content[target->b.nc], new_cont);
                    target->b.nc++;
                    struct node* copy=s;
                    while(copy)
                    {
                        if(copy->type==4)
                        {
                            for (int i=0; i<copy->g.busi; i++)
                            {
                                if (copy->g.bus[i].uid==target->uid)
                                {
                                    strcpy(copy->g.bus[i].content[copy->g.bus[i].nc++], new_cont);
                                }
                            }
                        }
                        copy=copy->next;
                    }
                }
            }
            if(!search_post_global(new_cont))
            {
                strcpy(post[pi++],new_cont);
            }
        }
        printf ("The existing content is:\n");
        for (int i=0; i<target->nc; i++)
        printf ("%s\n", target->content[i]);
        return s;
    }
}
//Function to search the content of a node
//Takes in input of the node to be searched, and then the content, and displays accordingly
void search_content()
{
    int id;
    printf ("Enter the uid of the node to be searched: ");
    scanf ("%d", &id);
    struct node* target=search(4, NULL, id);
    if (!target)
    printf ("The node does not exist!\n");
    else
    {
        int flag=0;
        char* cont_search=(char*)malloc(100*sizeof(char));
        printf ("Enter content to be searched for: ");
        scanf (" %[^\n]%*c", cont_search);
        for(int i=0; i<target->nc; i++)
        {
            if (strstr(target->content[i], cont_search))
            {
                flag=1;
                printf ("Content found!\n%s\n", target->content[i]);
            }
        }
        if(!flag)
        printf ("Content not found!\n");
    }
}
//Prints all one hop linked nodes of a given node
//One hop nodes of an individual refer to all the groups, organisations or business it is a part of
//One hop nodes of a group, individual or business are all the individuals linked to it
void print_one_hop()
{
    int id;
    printf ("Enter the uid of the node: ");
    scanf ("%d", &id);
    struct node* target=search(4, NULL, id);
    if (!target)
    printf ("The node does not exist!\n");
    else
    {
        if (target->type==2)
        {
            printf ("One hop nodes are:\n");
            for (int i=0; i<target->b.on; i++)
            {
                print1 (target->b.owner[i]);
            }
            for (int i=0; i<target->b.cn; i++)
            {
                print1 (target->b.cust[i]);
            }
        }
        if (target->type==3)
        {
            printf ("One hop nodes are:\n");
            for (int i=0; i<target->o.m; i++)
            print1(target->o.member[i]);
        }
        if (target->type==4)
        {
            printf ("One hop nodes are:\n");
            for (int i=0; i<target->g.memb; i++)
            print1(target->g.member[i]);
            for (int i=0; i<target->g.busi; i++)
            print2(target->g.bus[i]);
        }
        else
        {
            struct node* c=s;
            int count=0;
            printf ("One hop nodes are:\n");
            while(c)
            {
                if (c->type==2)
                {
                    for(int i=0; i<c->b.on; i++)
                    {
                        if (c->b.owner[i].uid==target->uid)
                        {
                            printf ("Unique ID: %d\nName: %s\n", c->uid, c->name);
                            count++;
                            break;
                        }
                    }
                    for(int i=0; i<c->b.cn; i++)
                    {
                        if (c->b.cust[i].uid==target->uid)
                        {
                            printf ("%s\n", c->name);
                            count++;
                            break;
                        }
                    }
                }
                else if (c->type==3)
                {
                    for(int i=0; i<c->o.m; i++)
                    {
                        if (c->o.member[i].uid==target->uid)
                        {
                            printf ("%s\n", c->name);
                            count++;
                            break;
                        }
                    }
                }
                else if (c->type==4)
                {
                    for(int i=0; i<c->g.memb; i++)
                    {
                        if (c->g.member[i].uid==target->uid)
                        {
                            printf ("%s\n", c->name);
                            count++;
                            break;
                        }
                    }
                    for(int i=0; i<c->g.busi; i++)
                    {
                        if (c->g.bus[i].uid==target->uid)
                        {
                            printf ("%s\n", c->name);
                            count++;
                            break;
                        }
                    }
                }
                c=c->next;
            }
        }
    }
}
//Printing content of all one hop nodes of a given node
void cont()
{
    int id;
    printf ("Enter the uid of the node: ");
    scanf("%d", &id);
    struct node* target=s;
    while(target)
    {
        if(target->uid==id)
        break;
        target=target->next;
    }
    if (!target)
    printf ("The node does not exist!\n");
    else
    {
        if (target->type==4)
        {
            printf ("Given node is not an individual!\n");
        }
        else
        {
            struct node* c=s;
            int count=0;
            while(c)
            {
                if (c->type==2)
                {
                    int flag=0;
                    for(int i=0; i<c->b.on; i++)
                    {
                        if (c->b.owner[i].uid==target->uid)
                        {
                            for (int j=0; j<c->b.on; j++)
                            {
                                if(c->b.owner[j].uid!=target->uid)
                                printc(c->b.owner[j]);
                            }
                            for (int j=0; j<c->b.cn; j++)
                            {
                                if(c->b.cust[j].uid!=target->uid)
                                printc(c->b.cust[j]);
                            }
                            count++;
                            flag=1;
                            break;
                        }
                    }
                    if(flag==0)
                    {
                        for(int i=0; i<c->b.cn; i++)
                        {
                            if (c->b.cust[i].uid==target->uid)
                            {
                                for (int j=0; j<c->b.on; j++)
                                {
                                    if(c->b.owner[j].uid!=target->uid)
                                    printc(c->b.owner[i]);
                                }
                                for (int j=0; j<c->b.cn; j++)
                                {
                                    if(c->b.cust[j].uid!=target->uid)
                                    printc(c->b.cust[i]);
                                }
                                count++;
                                break;
                            }
                        }
                    }
                }
                if (c->type==3)
                {
                    for(int i=0; i<c->o.m; i++)
                    {
                        if (c->o.member[i].uid==target->uid)
                        {
                            for (int j=0; j<c->o.m; j++)
                            {
                                if(c->o.member[j].uid!=target->uid)
                                printc(c->o.member[j]);
                            }
                            count++;
                            break;
                        }
                    }
                }
                if (c->type==4)
                {
                    for(int i=0; i<c->g.memb; i++)
                    {
                        if (c->g.member[i].uid==target->uid)
                        {
                            for (int j=0; j<c->g.memb; j++)
                            {
                                if(c->g.member[j].uid!=target->uid)
                                printc(c->g.member[j]);
                            }
                            count++;
                            break;
                        }
                    }
                }
                c=c->next;
            }
        }
    }
}
struct node* create_link()
{
    int id;
    printf ("Enter the unique id of the node to create a new link: ");
    scanf ("%d", &id);
    struct node* target=search(4, NULL, id);
    if (!target)
    {
        printf ("Node does not exist!\n");
        return s;
    }
    else
    {
        if (target->type==3||target->type==4)
        {
            printf ("Groups and organisations are individual nodes and cannot be nested within any other node!\n");
            return s;
        }
        if(target->type==1)
        {
            int id2;
            printf ("Enter the uid of the node to link it to: ");
            scanf ("%d", &id2);
            struct node* t2=search(4, NULL, id2);
            if (!t2)
            {
                printf ("Node does not exist!\n");
                return s;
            }
            else
            {
                if(t2->type==1)
                printf ("An individual cannot be linked to another individual!\n");
                else if(t2->type==2)
                {
                    int c;
                    printf ("Do you want to add as owner or customer? Type 1 for owner, 2 for customer: ");
                    scanf ("%d", &c);
                    if(c==1)
                    {
                        t2->b.owner[t2->b.on++]=target->i;
                        printf ("Successfully linked!\n");
                    }
                    else if(c==2)
                    {
                        t2->b.cust[t2->b.cn++]=target->i;
                        printf ("Successfully linked!\n");
                    }
                    else
                    printf ("Wrong type entered!\n");
                }
                else if(t2->type==3)
                {
                    t2->o.member[t2->o.m++]=target->i;
                    printf ("Successfully linked!\n");
                }
                else if(t2->type==4)
                {
                    t2->g.member[t2->g.memb]=target->i;
                    printf ("Successfully linked!\n");
                }
                return s;
            }
        }
        if(target->type==2)
        {
            int id2;
            printf ("Enter the uid of the node to link it to: ");
            scanf ("%d", &id2);
            struct node* t2=search(4, NULL, id2);
            if (!t2)
            {
                printf ("Node does not exist!\n");
                return s;
            }
            else
            {
                if(t2->type!=4)
                printf ("A business cannot be linked to anything other than a group!\n");
                else
                {
                    t2->g.bus[t2->g.busi++]=target->b;
                    printf ("Successfully linked!\n");
                }
                return s;
            }
        }
    }
}
//Main function, to implement the master text based interface
//It prints a menu of options, asking user to enter its choices and inputs and exits when the user does not want to make any more requests
int main()
{
    int ch;
    char w;
    post=(char**)malloc(sizeof(char*)*10000);//Initialising the global post array
    for (int i=0; i<10000; i++)
    post[i]=(char*)malloc(1000*sizeof(char));
    s=(struct node*)malloc(10000*sizeof(struct node));//Initialising the global linked list of nodes
    s=NULL;
    do
    {
        printf ("********************************************************\n");
        printf ("Menu:\n1.Create Node\n2.Delete Node\n3.Search for a node\n4.Print 1 hop nodes\n5.Create and post content of a node\n6.Search for content posted by a node\n7.Display content posted by all linked nodes\n8.Display content of all nodes\n9.Create new links\n10.Quit\nEnter your choice: ");
        scanf ("%d", &ch);
        printf ("********************************************************\n");
        switch(ch)
        {
            case 1: s=create();
                break;
            case 2: printf ("Enter the id to be deleted: ");
                int id;
                scanf("%d", &id);
                s=delete (id);
                break;
            case 3: printf ("Type 1 to search by name, 2 to search by birth(only for individuals), 3 to search by type\n");
                printf ("Type 1 is an individual\nType 2 is a business\nType 3 is an organisation\nType 4 is a group\nEnter your choice: ");
                int choice;
                struct node* res;
                scanf ("%d", &choice);
                if (choice==1||choice==2)
                {
                    printf ("Enter data: ");
                    char* dat=(char*)malloc(1000*sizeof(char));
                    scanf (" %[^\n]%*c", dat);
                    res=search(choice, dat, -1);
                }
                else if (choice==3)
                {
                    printf ("Enter type: ");
                    int t;
                    scanf ("%d", &t);
                    res=search(choice, NULL, t);
                }
                else
                {
                    printf ("Wrong choice!\n");
                    continue;
                }
                if (res)
                printf ("Search successful!\n");
                else
                printf ("Data not found!\n");
                break;
            case 4: print_one_hop();
                break;
            case 5: s=cont_post();
                break;
            case 6: search_content();
                break;
            case 7: cont();
                break;
            case 8: display();
                break;
            case 9: s=create_link();
                break;
            case 10: printf ("Now quitting\n");
                exit(0);
                break;
            default: printf ("Wrong choice!\n");
        }
        printf ("Do you want to make any more requests?(Y/N): ");
        scanf (" %c", &w);
        printf ("********************************************************\n");
    } while (w=='Y'||w=='y');
}